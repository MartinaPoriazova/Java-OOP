package zoo;

public class Reptile extends Animal{

    public Reptile(String name) {
        super(name);
    }
}
