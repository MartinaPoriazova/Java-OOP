package pointInRectangle;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Point bottomLeft = new Point(0, 0);
        Point topRight = new Point(2, 2);

        Rectangle rectangle = new Rectangle(bottomLeft, topRight);

        System.out.println(rectangle.contains(new Point(1, 1)));
        System.out.println(rectangle.contains(new Point(2, 3)));
    }

}
