package shortage;

public interface Identifiable {

    String getId();
}
