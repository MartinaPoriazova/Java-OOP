package shortage;

public interface Birthable {
    String getBirthDate();

}
