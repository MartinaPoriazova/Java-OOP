package person;

public interface Identifiable {

    public abstract String getId();

}
