package person;

public interface Birthable {

    public abstract String getBirthDate();

}
