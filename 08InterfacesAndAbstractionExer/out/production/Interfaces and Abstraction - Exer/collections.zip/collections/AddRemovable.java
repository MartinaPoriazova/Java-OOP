package collections;

public interface AddRemovable extends Addable {

    String remove();

}
