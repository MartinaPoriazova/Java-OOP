package harvestingFields;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Class<RichSoilLand> clazz = RichSoilLand.class;
        Field[] fields = clazz.getDeclaredFields();

        String input = scanner.nextLine();

        while (!input.equals("HARVEST")) {
            switch (input) {
                case "public":
                    Arrays.stream(fields).filter(field -> Modifier.isPublic(field.getModifiers())).
                            forEach(field -> {
                               printField(field);
                                    });
//                    for (Field field : fields) {
//                        Modifier.isPublic(field.getModifiers());
//                        System.out.printf("%s %s %S\n",
//                                Modifier.toString(field.getModifiers()),
//                                field.getType().getSimpleName(),
//                                field.getName());
//                    }
                    break;
                case "private":
                    Arrays.stream(fields).filter(field -> Modifier.isPrivate(field.getModifiers())).
                            forEach(field -> {
                                printField(field);
                            });
                    break;
                case "protected":
                    Arrays.stream(fields).filter(field -> Modifier.isProtected(field.getModifiers())).
                            forEach(field -> {
                                printField(field);
                            });
                    break;
                case "all":
                    Arrays.stream(fields).
                            forEach(field -> {
                                printField(field);
                            });
                    break;
            }
            input = scanner.nextLine();
        }
    }

    private static void printField(Field field) {
        System.out.printf("%s %s %S\n",
                Modifier.toString(field.getModifiers()),
                field.getType().getSimpleName(),
                field.getName());
    }
}
