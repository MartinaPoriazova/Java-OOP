package wildfarm;

public abstract class Felime extends Mammal {

    public Felime(String animalName, String animalType, double animalWeight, int foodEaten, String livingRegion) {
        super(animalName, animalType, animalWeight, foodEaten, livingRegion);
    }
}
